import math
import makematrix
import thomas


def compare(x, y, tolerance):
    summed = 0
    if len(x) != len(y):
        raise ValueError('Cannot compare X and Y!')
    n = len(x)
    for i in range(0, n):
        summed += (x[i] - y[i])**2
    if math.sqrt(summed)/n < tolerance:
        return True
    else:
        return False


def convection(sim, field, cycle):

    if sim.last_cycle == 1:
        if field == 1:
            sim.tds_high[0] = [sim.X[i] for i in range(sim.mcm_ind1, sim.mcm_ind2)]

        if field == 0:
            sim.tds_low[0] = [sim.X[i] for i in range(sim.mcm_ind1, sim.mcm_ind2)]

        sim.source_temps.append(sim.X[0])
        sim.sink_temps.append(sim.X[-1])

    for k in range(0, sim.m):
        X_orig = sim.X
        X_mod = sim.X
        X_old = sim.X
        while True:
            underdiags, diags, upperdiags, right_sides = makematrix.make_matrix(sim, field, X_mod, X_orig)
            X_mod = thomas.thomas(underdiags[1:], diags, upperdiags[:-1], right_sides)
            flag = compare(X_mod, X_old, sim.tolerance)
            if flag:
                break
            X_old = X_mod

        underdiags, diags, upperdiags, right_sides = makematrix.make_matrix(sim, field, X_mod, X_orig)

        sim.X = thomas.thomas(underdiags[1:], diags, upperdiags[:-1], right_sides)

        if sim.last_cycle == 1:
            if field == 1:
                sim.tds_high[k + 1] = [sim.X[i] for i in range(sim.mcm_ind1, sim.mcm_ind2)]

            if field == 0:
                sim.tds_low[k + 1] = [sim.X[i] for i in range(sim.mcm_ind1, sim.mcm_ind2)]

            sim.source_temps.append(sim.X[0])
            sim.sink_temps.append(sim.X[-1])
