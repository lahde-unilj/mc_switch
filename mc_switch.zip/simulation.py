# order of variables throughout the program: 1 = source, 2 = switch A, 3 = mcm, 4 = switch B, 5 = sink
# import smallest


class Simulation:
    # ========================== user-defined variables =============================#
    def __init__(self, switch_th, mcm_th, hex_th):
        self.path = 'results/'
        self.st_data_filename = 'data/s_total_Gd.txt'
        self.result_name = 'r_' + str(switch_th) + '_' + str(mcm_th) + '_' + str(hex_th)
        self.isDone = 0

        self.rho_source = 8960
        self.rho_sink = self.rho_source
        self.rho_switch = 2430
        self.rho_mcm = 7900

        self.cp_source = 380
        self.cp_sink = self.cp_source
        self.cp_switch = 1957
        
        self.k_source = 300
        self.k_sink = self.k_source
        self.k_on = 0.12  # W/mK
        self.k_off = 0.08
        self.k_mcm = 10.5

        self.q_left = 0   # q_source, cooling power
        self.h_right = 10000  # W/Km2
        self.right_temp = 293  # K

        self.switch_work = 0  # in W/m2 work input that is required for the switch to operate.
        # This value is only used in COP calculation (in runcycles.py)

        self.resist_12 = 0  # in m2K/W contact thermal resistance - zero in ideal case
        self.resist_23 = 0
        self.resist_34 = self.resist_23
        self.resist_45 = 0

        self.generated_heat_on = 0  # in W/m3 Internal heat generation, see line 106.
        self.generated_heat_off = 0  # in W/m3

        self.low_field = 0.5  # in Tesla. When passing field to functions use boolean variable 0.
        self.high_field = 1.4  # in Tesla. When passing field to functions use boolean variable 1.

        self.start_temperature = 293  # Starting temperature for all nodes.

        self.t_mag = 0.005
        self.freq = 0.1
        self.tolerance = 0.1  # for inner iteration
        self.end_tolerance = 10 ** (-5)  # for end of simulation (min. 10^-7 for max. accuracy)
        self.N = 10  # minimal number of cycles

        self.n0 = 10  # discretization (number of nodes) of heat source and heat sink
        self.n1 = 20  # disretization (number of nodes) of each thermal switch
        self.n2 = 40  # discretization (number of nodes) of caloric material
        self.t_transfer = (1.0 / self.freq - 2.0 * self.t_mag) / 2.0
        self.time_step = self.t_transfer / 17000.0
        self.print_cycle = int(self.N / self.N)  # print the values of X every >>print_cycle<< cycles

        # =============================== end user-defined ===============================#

        self.hex_dx = hex_th / self.n0
        self.switch_dx = switch_th / self.n1
        self.mcm_dx = mcm_th / self.n2

        self.hex_th = hex_th
        self.switch_th = switch_th
        self.mcm_th = mcm_th

        self.n = [self.n0, self.n1, self.n2, self.n1, self.n0]

        self.temperatures_st = []
        self.low_field_entropies = []
        self.high_field_entropies = []
        self.derivative_st_low = []
        self.derivative_st_high = []
        self.lambdas_mcm = []
        self.lambdas_a = []
        self.lambdas_b = []
        self.spec_heats_a = []
        self.spec_heats_b = []
        self.temps_cp_k_a = []
        self.temps_cp_k_b = []
        self.temps_k_mcm = []

        # ===============================================================================#

        self.min_field = 0  # in Tesla, set automatically.
        self.max_field = 0  # in Tesla, set automatically.
        self.field_step = 0  # in Tesla, set automatically.

        self.m = int(round(self.t_transfer / self.time_step, 0))  # number of time steps during heat transfer.

        self.sim_time = 0
        self.cycle = 0
        self.last_cycle = 0
        self.check_list = [0, 1, 2, -1, -2, -3]

        self.X = self.n[0]*[self.start_temperature] + \
            self.n[1]*[self.start_temperature] + \
            self.n[2]*[self.start_temperature] + \
            self.n[3]*[self.start_temperature] + \
            self.n[4]*[self.start_temperature]

        self.q_gen_l_on = self.generated_heat_on * self.switch_th
        self.q_gen_l_off = self.generated_heat_off * self.switch_th
        self.q_gen_r_on = self.generated_heat_on * self.switch_th
        self.q_gen_r_off = self.generated_heat_off * self.switch_th

        self.q_heat = 0
        self.q_cool = 0
        self.d_temp_max = 0
        self.mag_work = 0
        self.heat_flow = 0

        self.source_average = 0
        self.sink_average = 0
        self.fluctuation_cold = 0
        self.fluctuation_hot = 0

        self.mcm_ind1 = sum(self.n[0:2])
        self.mcm_ind2 = sum(self.n[0:3])

        self.tds_high = []
        self.tds_low = []
        self.source_temps = []
        self.sink_temps = []
