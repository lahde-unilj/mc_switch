import magnetization
import heat_transfer
import myprint


def cycle(sim, results, results_temps):

    magnetization.magnetize(sim, 0)
    sim.sim_time += sim.t_mag
    
    if sim.cycle % sim.print_cycle == 0:
        myprint.print_darray_row(sim.X, results, 4, sim.sim_time, sim.cycle)
    
    heat_transfer.convection(sim, 1, sim.cycle)
    sim.sim_time += sim.t_transfer

    if sim.cycle % sim.print_cycle == 0:
        myprint.print_darray_row(sim.X, results, 4, sim.sim_time, sim.cycle)

    if sim.cycle > sim.N and sim.cycle % sim.print_cycle == 0:
        sim.q_heat = (sim.X[-1] - sim.right_temp) * sim.h_right

    magnetization.magnetize(sim, 1)
    sim.sim_time += sim.t_mag
    
    if sim.cycle % sim.print_cycle == 0:
        myprint.print_darray_row(sim.X, results, 4, sim.sim_time, sim.cycle)

    heat_transfer.convection(sim, 0, sim.cycle)
    sim.sim_time += sim.t_transfer

    if sim.cycle % sim.print_cycle == 0:
        myprint.print_darray_row(sim.X, results, 4, sim.sim_time, sim.cycle)
        myprint.print_darray_row(sim.X, results_temps, 4, sim.sim_time, sim.cycle)

    sim.cycle += 1

