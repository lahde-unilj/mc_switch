import numpy as np


def left_heatflux(sim, field, Z):
    cpl = sim.cp_source
    kl = sim.k_source
    q = sim.q_left   # input heat flow

    a = 0
    b = kl * sim.time_step + sim.rho_source * cpl * sim.hex_dx**2/2
    c = -kl * sim.time_step
    z = q * sim.time_step * sim.hex_dx + (sim.rho_source * cpl * sim.hex_dx**2/2) * Z[0]

    return a, b, c, z


def right_convection(sim, field, Z):
    cpd = sim.cp_sink
    kd = sim.k_sink
    h = sim.h_right

    a = -kd * sim.time_step
    b = (h * sim.hex_dx + kd) * sim.time_step + sim.rho_sink * cpd * sim.hex_dx ** 2 / 2
    c = 0
    z = h * sim.right_temp * sim.time_step * sim.hex_dx + (sim.rho_sink * cpd * sim.hex_dx ** 2 / 2) * Z[-1]

    return a, b, c, z


def inner_transfer(sim, part, j, field, X, Z):

    rho, k, cp, q_gen, dx = 0, 0, 0, 0, 0

    if part == 1:
        rho = sim.rho_source
        k = sim.k_source
        cp = sim.cp_source
        dx = sim.hex_dx
    if part == 2:
        rho = sim.rho_switch
        k = sim.k_off if field else sim.k_on
        q_gen = sim.q_gen_l_off if field else sim.q_gen_l_on
        # cp = np.interp(X[j], sim.temps_cp_k_a, sim.spec_heats_a)
        cp = sim.cp_switch
        dx = sim.switch_dx
    if part == 4:
        rho = sim.rho_switch
        k = sim.k_on if field else sim.k_off
        q_gen = sim.q_gen_r_on if field else sim.q_gen_r_off
        # cp = np.interp(X[j], sim.temps_cp_k_b, sim.spec_heats_b)
        cp = sim.cp_switch
        dx = sim.switch_dx
    if part == 5:
        rho = sim.rho_sink
        k = sim.k_sink
        cp = sim.cp_sink
        dx = sim.hex_dx

    a = -k * sim.time_step
    b = 2 * k * sim.time_step + rho * cp * dx**2
    c = -k * sim.time_step
    z = (rho * cp * dx**2) * Z[j] + q_gen*sim.time_step*dx

    return a, b, c, z


def mcm_inner_transfer(sim, j, field, X, Z):
    # k1 = np.interp((X[j - 1] + X[j]) / 2, sim.temps_k_mcm, sim.lambdas_mcm)
    # k2 = np.interp((X[j + 1] + X[j]) / 2, sim.temps_k_mcm, sim.lambdas_mcm)
    k1 = sim.k_mcm
    k2 = sim.k_mcm

    cp = 0.0
    if field == 0:
        cp = X[j] * np.interp(X[j], sim.temperatures_st, sim.derivative_st_low)
    if field == 1:
        cp = X[j] * np.interp(X[j], sim.temperatures_st, sim.derivative_st_high)

    a = -k1 * sim.time_step
    b = (k1 + k2) * sim.time_step + sim.rho_mcm * cp * sim.mcm_dx**2
    c = -k2 * sim.time_step
    z = (sim.rho_mcm * cp * sim.mcm_dx**2) * Z[j]

    return a, b, c, z


def border_left(sim, part1, part2, field, X, Z):
    j, k1, k2, cp, rho, q_gen, ke, k11, k22, dx = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    #ke je enaka 1/Rtotal, nima enot topl. prevodnosti! Rtotal=dx1/2k1 +dx2/2k2+ Rcont

    if part1 == 1 and part2 == 2:
        j = sim.n[0]-1
        k1 = sim.k_source
        k2 = sim.k_off if field else sim.k_on
        ke = 2 * k1 * k2 /(sim.hex_dx * k2 + sim.switch_dx * k1 + 2 * k1 * k2 * sim.resist_12)
        cp = sim.cp_source
        rho = sim.rho_source
        dx = sim.hex_dx

    if part1 == 2 and part2 == 3:
        j = sim.n[0] + sim.n[1] - 1
        k1 = sim.k_off if field else sim.k_on
        k2 = sim.k_mcm
        ke = 2 * k1 * k2 /(sim.switch_dx * k2 + sim.mcm_dx * k1 + 2 * k1 * k2 * sim.resist_23)
        cp = sim.cp_switch
        q_gen = sim.q_gen_l_off if field else sim.q_gen_l_on
        rho = sim.rho_switch
        dx = sim.switch_dx

    if part1 == 3 and part2 == 4:
        j = sum(sim.n[0:3])-1
        k1 = sim.k_mcm
        k2 = sim.k_on if field else sim.k_off
        ke = 2 * k1 * k2 /(sim.mcm_dx * k2 + sim.switch_dx * k1 + 2 * k1 * k2 * sim.resist_23)
        if field == 0:
            cp = X[j] * np.interp(X[j], sim.temperatures_st, sim.derivative_st_low)
        if field == 1:
            cp = X[j] * np.interp(X[j], sim.temperatures_st, sim.derivative_st_high)
        rho = sim.rho_mcm
        dx = sim.mcm_dx

    if part1 == 4 and part2 == 5:
        j = sum(sim.n[0:4]) - 1
        k1 = sim.k_on if field else sim.k_off
        k2 = sim.k_sink
        ke = 2 * k1 * k2 /(sim.switch_dx * k2 + sim.hex_dx * k1 + 2 * k1 * k2 * sim.resist_12)
        cp = sim.cp_switch
        rho = sim.rho_switch
        q_gen = sim.q_gen_r_on if field else sim.q_gen_r_off
        dx = sim.switch_dx

    a = -k1 * sim.time_step
    b = k1 * sim.time_step + ke * dx * sim.time_step + rho * cp * (dx ** 2)
    c = -ke * dx * sim.time_step
    z = rho * cp * (dx ** 2) * Z[j] + q_gen*sim.time_step*dx

    return a, b, c, z


def border_right(sim, part1, part2, field, X, Z):
    j, k1, k2, cp, rho, q_gen, ke, k11, k22, dx = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0

    if part1 == 1 and part2 == 2:
        j = sim.n[0]
        k1 = sim.k_source
        k2 = sim.k_off if field else sim.k_on
        ke = 2 * k1 * k2 /(sim.switch_dx * k1 + sim.hex_dx * k2 + 2 * k1 * k2 * sim.resist_12)
        cp = sim.cp_switch
        rho = sim.rho_switch
        q_gen = sim.q_gen_l_off if field else sim.q_gen_l_on
        dx = sim.switch_dx

    if part1 == 2 and part2 == 3:
        j = sim.n[0] + sim.n[1]
        k1 = sim.k_off if field else sim.k_on
        k2 = sim.k_mcm
        ke = 2 * k1 * k2 /(sim.mcm_dx * k1 + sim.switch_dx * k2 + 2 * k1 * k2 * sim.resist_23)
        if field == 0:
            cp = X[j] * np.interp(X[j], sim.temperatures_st, sim.derivative_st_low)
        if field == 1:
            cp = X[j] * np.interp(X[j], sim.temperatures_st, sim.derivative_st_high)
        rho = sim.rho_mcm
        dx = sim.mcm_dx

    if part1 == 3 and part2 == 4:
        j = sum(sim.n[0:3])
        k1 = sim.k_mcm
        k2 = sim.k_on if field else sim.k_off
        ke = 2 * k1 * k2 /(sim.switch_dx * k1 + sim.mcm_dx * k2 + 2 * k1 * k2 * sim.resist_23)
        q_gen = sim.q_gen_r_on if field else sim.q_gen_r_off
        # cp = np.interp(X[j], sim.temps_cp_k_b, sim.spec_heats_b)
        cp = sim.cp_switch
        rho = sim.rho_switch
        dx = sim.switch_dx

    if part1 == 4 and part2 == 5:
        j = sum(sim.n[0:4])
        k1 = sim.k_on if field else sim.k_off
        k2 = sim.k_sink
        ke = 2 * k1 * k2 /(sim.hex_dx * k1 + sim.switch_dx * k2 + 2 * k1 * k2 * sim.resist_12)
        cp = sim.cp_sink
        rho = sim.rho_sink
        q_gen = 0
        dx = sim.hex_dx

    a = -ke * sim.time_step * dx
    b = ke * dx * sim.time_step + k2 * sim.time_step + rho * cp * (dx ** 2)
    c = -k2 * sim.time_step
    z = rho * cp * (dx ** 2) * Z[j] + q_gen*sim.time_step*dx

    return a, b, c, z


def make_matrix(sim, field, X, Z):
    system_equations = [[0, 0, 0, 0] for k in range(0, sum(sim.n))]

    a, b, c, z = left_heatflux(sim, field, Z)
    system_equations[0] = [a, b, c, z]

    for j in range(1, sim.n[0]-1):
        a, b, c, z = inner_transfer(sim, 1, j, field, X, Z)
        system_equations[j] = [a, b, c, z]

    a, b, c, z = border_left(sim, 1, 2, field, X, Z)
    system_equations[sim.n[0]-1] = [a, b, c, z]

    a, b, c, z = border_right(sim, 1, 2, field, X, Z)
    system_equations[sim.n[0]] = [a, b, c, z]

    for j in range(sim.n[0] + 1, sim.n[0] + sim.n[1] - 1):
        a, b, c, z = inner_transfer(sim, 2, j, field, X, Z)
        system_equations[j] = [a, b, c, z]

    a, b, c, z = border_left(sim, 2, 3, field, X, Z)
    system_equations[sim.n[0] + sim.n[1] - 1] = [a, b, c, z]

    a, b, c, z = border_right(sim, 2, 3, field, X, Z)
    system_equations[sim.n[0] + sim.n[1]] = [a, b, c, z]

    for j in range(sim.n[0] + sim.n[1] + 1, sum(sim.n[0:3])-1):
        a, b, c, z = mcm_inner_transfer(sim, j, field, X, Z)
        system_equations[j] = [a, b, c, z]

    a, b, c, z = border_left(sim, 3, 4, field, X, Z)
    system_equations[sum(sim.n[0:3])-1] = [a, b, c, z]

    a, b, c, z = border_right(sim, 3, 4, field, X, Z)
    system_equations[sum(sim.n[0:3])] = [a, b, c, z]

    for j in range(sum(sim.n[0:3]) + 1, sum(sim.n[0:4]) - 1):
        a, b, c, z = inner_transfer(sim, 4, j, field, X, Z)
        system_equations[j] = [a, b, c, z]

    a, b, c, z = border_left(sim, 4, 5, field, X, Z)
    system_equations[sum(sim.n[0:4]) - 1] = [a, b, c, z]

    a, b, c, z = border_right(sim, 4, 5, field, X, Z)
    system_equations[sum(sim.n[0:4])] = [a, b, c, z]

    for j in range(sum(sim.n[0:4])+1, sum(sim.n) - 1):
        a, b, c, z = inner_transfer(sim, 5, j, field, X, Z)
        system_equations[j] = [a, b, c, z]

    a, b, c, z = right_convection(sim, field, Z)
    system_equations[-1] = [a, b, c, z]

    underdiags = [el[0] for el in system_equations]
    diagonals = [el[1] for el in system_equations]
    upperdiags = [el[2] for el in system_equations]
    right_sides = [el[3] for el in system_equations]

    return underdiags, diagonals, upperdiags, right_sides
