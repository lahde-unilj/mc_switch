import numpy as np


def magnetize(sim, field):
    ind1 = sum(sim.n[0:2])
    ind2 = sum(sim.n[0:3])

    if field == 0:
        for j in range(ind1, ind2):
            entropy = np.interp(sim.X[j], sim.temperatures_st, sim.low_field_entropies)
            new_temperature = np.interp(entropy, sim.high_field_entropies, sim.temperatures_st)
            sim.X[j] = new_temperature

    if field == 1:
        for j in range(ind1, ind2):
            entropy = np.interp(sim.X[j], sim.temperatures_st, sim.high_field_entropies)
            new_temperature = np.interp(entropy, sim.low_field_entropies, sim.temperatures_st)
            sim.X[j] = new_temperature
