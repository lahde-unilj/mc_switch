# order of variables throughout the program: 1 = source, 2 = switch A, 3 = mcm, 4 = switch B, 5 = sink


class Simulation:
    # ========================== user-defined variables =============================#
    # The constructor of the Simulation class takes three arguments: the thicknesses of both switches,
    # the caloric material and the source/sink
    def __init__(self, switch_th, mcm_th, hex_th):
        self.path = 'results/'
        self.st_data_filename = 'data/s_total_Gd.txt'
        self.result_name = 'r_' + str(switch_th) + '_' + str(mcm_th) + '_' + str(hex_th)
        self.isDone = 0

        self.rho_source = 8960  # kg/m^3
        self.rho_sink = self.rho_source
        self.rho_switch = 2430  # kg/m^3
        self.rho_mcm = 7900  # kg/m^3

        self.cp_source = 380  # J/kg/K
        self.cp_sink = self.cp_source
        self.cp_switch = 1957  # J/kg/K
        
        self.k_source = 100  # W/m/K
        self.k_sink = self.k_source
        self.k_on = 1  # W/m/K
        self.k_off = 0.1  # W/m/K
        self.k_mcm = 10.5  # W/m/K

        self.q_left = 0   # q_source; cooling power
        self.h_right = 10000  # W/K/m^2
        self.right_temp = 293  # K

        self.switch_work = 0  # W/m^2; work input that is required for the switch to operate
        # This value is only used in COP calculation (in runcycles.py)

        self.resist_12 = 0  # m^2K/W; contact thermal resistance - zero in ideal case
        self.resist_23 = 0  # m^2K/W
        self.resist_34 = self.resist_23
        self.resist_45 = 0  # m^2K/W

        self.generated_heat_on = 0  # W/m^3; internal heat generation
        self.generated_heat_off = 0  # W/m^3

        self.low_field = 0  # Tesla. External field density during low isofield. When passing field to functions use boolean variable 0.
        self.high_field = 1  # Tesla. External field density during high isofield.  When passing field to functions use boolean variable 1.

        self.start_temperature = 293  # Starting temperature for all nodes.

        self.t_mag = 0.005  # Duration of magnetization [s]
        self.freq = 5  # Cycling frequency [Hz]
        self.tolerance = 0.1  # Stopping condition for inner iteration (in current time step)
        self.end_tolerance = 10 ** (-6)  # Stopping condition for stopping the simulation (min. 10^-7 for max. accuracy)
        self.N = 10  # Minimal number of cycles

        self.n0 = 10  # Discretization (number of nodes) of heat source and heat sink
        self.n1 = 20  # Disretization (number of nodes) of each thermal switch
        self.n2 = 40  # Discretization (number of nodes) of caloric material
        self.t_transfer = (1.0 / self.freq - 2.0 * self.t_mag) / 2.0  # Seconds; duration of heat transfer process
        self.time_step = self.t_transfer / 50000.0  # Seconds; time step of the simulation
        self.print_cycle = int(self.N / self.N)  # Print the values of X every >>print_cycle<< cycles

        # =============================== end user-defined ===============================#

        self.hex_dx = hex_th / self.n0  # m; space discretisation step for the source/sink
        self.switch_dx = switch_th / self.n1  # m; space discretisation step for the source/sink
        self.mcm_dx = mcm_th / self.n2  # m; space discretisation step for the source/sink

        self.hex_th = hex_th
        self.switch_th = switch_th
        self.mcm_th = mcm_th

        self.n = [self.n0, self.n1, self.n2, self.n1, self.n0]  # List of nodes for the whole device.

        #  Lists for storing input data
        self.temperatures_st = []
        self.low_field_entropies = []
        self.high_field_entropies = []
        self.derivative_st_low = []
        self.derivative_st_high = []
        self.lambdas_mcm = []
        self.lambdas_a = []
        self.lambdas_b = []
        self.spec_heats_a = []
        self.spec_heats_b = []
        self.temps_cp_k_a = []
        self.temps_cp_k_b = []
        self.temps_k_mcm = []

        # ===============================================================================#

        self.min_field = 0  # Tesla; set automatically
        self.max_field = 0  # Tesla; set automatically
        self.field_step = 0  # Tesla; set automatically

        self.m = int(round(self.t_transfer / self.time_step, 0))  # Number of time steps during heat transfer

        self.sim_time = 0  # Seconds; time counter
        self.cycle = 0  # Cycle counter
        self.last_cycle = 0  # This attribute becomes 1 in the last cycle
        self.check_list = [0, 1, 2, -1, -2, -3]  # List of nodes used in simulation stopping condition

        # List of temperatures of all nodes of the device
        self.X = self.n[0]*[self.start_temperature] + \
            self.n[1]*[self.start_temperature] + \
            self.n[2]*[self.start_temperature] + \
            self.n[3]*[self.start_temperature] + \
            self.n[4]*[self.start_temperature]

        self.q_gen_l_on = self.generated_heat_on * self.switch_th
        self.q_gen_l_off = self.generated_heat_off * self.switch_th
        self.q_gen_r_on = self.generated_heat_on * self.switch_th
        self.q_gen_r_off = self.generated_heat_off * self.switch_th

        self.q_heat = 0  # W/m^2; heating power, calculated at the end
        self.q_cool = 0  # W/m^2; cooling power, calculated at the end
        self.d_temp_max = 0  # K; maximal temperature span of the device
        self.mag_work = 0  # W/m^2; this value is calculated at the end for checking the thermodynamical correctness of the model

        self.source_average = 0  # K; average temperature (in one cycle) at the end of the heat source
        self.sink_average = 0  # K; average temperature (in one cycle) at the end of the heat sink
        self.fluctuation_cold = 0  # K; fluctuation magnitude (in one cycle) at the end of the heat source
        self.fluctuation_hot = 0  # K; fluctuation magnitude (in one cycle) at the end of the heat sink

        self.mcm_ind1 = sum(self.n[0:2])  # Starting index of the caloric material
        self.mcm_ind2 = sum(self.n[0:3])  # Ending index of the caloric material

        self.tds_high = []  # List for storing T*ds values of separate time steps during high isofield
        self.tds_low = []  # List for storing T*ds values of separate time steps during low isofield
        self.source_temps = []  # List for storing temperatures at the end of heat source during heat transfer
        self.sink_temps = []  # List for storing temperatures at the end of heat sink during heat transfer
