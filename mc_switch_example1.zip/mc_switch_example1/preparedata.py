import numpy as np
from numpy import loadtxt
from os import path


# Function that stores the input data, in particular the total specific entropy data with respect to temperature and
# external magnetic field density for the caloric material, into the simulation object.
def initialize_data(sim):
    data = loadtxt(sim.st_data_filename)
    sim.temperatures_st = data[0][1:]
    fields = [data[k][0] for k in range(1, len(data))]
    sim.min_field = fields[0]
    sim.max_field = fields[-1]
    sim.field_step = fields[1] - fields[0]
    try:
        ind1 = fields.index(sim.low_field)
        ind2 = fields.index(sim.high_field)
        sim.low_field_entropies = data[ind1 + 1][1:]
        sim.high_field_entropies = data[ind2 + 1][1:]
        step = sim.temperatures_st[1] - sim.temperatures_st[0]
        sim.derivative_st_low = np.gradient(sim.low_field_entropies, step)
        sim.derivative_st_high = np.gradient(sim.high_field_entropies, step)
    except ValueError:
        print('MAGNETIC FIELD SHOULD BE BETWEEN %.2f AND %.2f IN %.4f STEPS.' % (sim.min_field, sim.max_field, sim.field_step))

    if path.exists(sim.path + 'resultFinished.txt'):
        with open(sim.path + 'resultFinished.txt', 'r') as read_obj:
            for line in read_obj:
                if sim.result_name + '.txt' in line:
                    sim.isDone = 1

    if path.exists(sim.path + sim.result_name + '.txt'):
        last_results = np.genfromtxt(sim.path + sim.result_name + '_temps.txt', skip_header=1, skip_footer=1)
        if len(last_results) > 1:
            sim.X = last_results[len(last_results) - 2][2:]

    sim.tds_high = [[0 for i in range(sim.n[2])] for j in range(sim.m + 1)]
    sim.tds_low = [[0 for ii in range(sim.n[2])] for jj in range(sim.m + 1)]
