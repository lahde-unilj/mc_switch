import magnetization
import heat_transfer
import myprint


# This function executes one cycle of the simulation.
def cycle(sim, results, results_temps):

    magnetization.magnetize(sim, 0)  # Magnetization
    sim.sim_time += sim.t_mag  # Simulation time increases for the duration of (de)magnetization

    # Prints temperatures after magnetization
    if sim.cycle % sim.print_cycle == 0:
        myprint.print_darray_row(sim.X, results, 4, sim.sim_time, sim.cycle)
    
    heat_transfer.convection(sim, 1, sim.cycle)  # Heat transfer process during high isofield
    sim.sim_time += sim.t_transfer  # Simulation time increases for the duration of the heat transfer process

    # Prints temperatures after the heat transfer process
    if sim.cycle % sim.print_cycle == 0:
        myprint.print_darray_row(sim.X, results, 4, sim.sim_time, sim.cycle)

    # Calculate heating power if we are close to the quasi-steady state
    if sim.cycle > sim.N and sim.cycle % sim.print_cycle == 0:
        sim.q_heat = (sim.X[-1] - sim.right_temp) * sim.h_right

    magnetization.magnetize(sim, 1)  # Demagnetization
    sim.sim_time += sim.t_mag  # Simulation time increases for the duration of (de)magnetization

    # Prints temperatures after demagnetization
    if sim.cycle % sim.print_cycle == 0:
        myprint.print_darray_row(sim.X, results, 4, sim.sim_time, sim.cycle)

    heat_transfer.convection(sim, 0, sim.cycle)  # Heat transfer process during low isofield
    sim.sim_time += sim.t_transfer  # Simulation time increases for the duration of the heat transfer process

    # Output temperatures of all nodes
    if sim.cycle % sim.print_cycle == 0:
        myprint.print_darray_row(sim.X, results, 4, sim.sim_time, sim.cycle)
        myprint.print_darray_row(sim.X, results_temps, 4, sim.sim_time, sim.cycle)

    sim.cycle += 1  # Increase the cycle counter by one

