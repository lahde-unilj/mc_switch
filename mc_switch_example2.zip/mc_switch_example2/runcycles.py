import simulation
import preparedata
import cycle
import heat_transfer
import magneticwork
import myprint
import time


start_time = time.time()

# Specify thicknesses of the device parts: switches, caloric material and heat source/sink
sw_th = 0.00005  # m
mcm_th = 0.0003  # m
hex_th = 0.0002  # m

my_sim = simulation.Simulation(sw_th, mcm_th, hex_th)  # Create simulation object
preparedata.initialize_data(my_sim)  # Input the entropy data for the caloric material

if my_sim.t_transfer < my_sim.time_step:
    raise ValueError('Time step too large!')

result_path = my_sim.path + my_sim.result_name
results = open(result_path + '.txt', 'a')
results_temps = open(result_path + '_temps.txt', 'a')

results_temps.write("\n")

myprint.print_simulation(my_sim, results)
myprint.print_darray_row(my_sim.X, results, 4, 0, my_sim.cycle)

check_vec = [my_sim.X[i] for i in my_sim.check_list]  # Create the list for checking if quasi-steady state is reached

# Run the simulation
while True:
    cycle.cycle(my_sim, results, results_temps)
    if my_sim.cycle > my_sim.N and my_sim.cycle % my_sim.print_cycle == 0:
        check = heat_transfer.compare([my_sim.X[i] for i in my_sim.check_list], check_vec, my_sim.end_tolerance)
        if check:
            my_sim.last_cycle = 1
            cycle.cycle(my_sim, results, results_temps)
            break
        check_vec = [my_sim.X[i] for i in my_sim.check_list]

magneticwork.mag_work(my_sim)  # Calculate magnetic work to check the validity of the model

# COP over the whole cycle - ON and OFF
cop = my_sim.q_cool / (my_sim.q_heat - my_sim.q_cool -
                       (my_sim.generated_heat_off + my_sim.generated_heat_on) * my_sim.switch_th + my_sim.switch_work * 2)
d_temp_max = my_sim.d_temp_max
if my_sim.q_cool < 0:
    cop = 0
    d_temp_max = 0

# Output results
results.write("\nmag_work (TdS) [W/m2] = " + str(my_sim.mag_work))
results.write("\nmag_work(Q_sink - q_source - Q_gen_total) [W/m2] = " +
              str(my_sim.q_heat - my_sim.q_cool - (
                          my_sim.generated_heat_off + my_sim.generated_heat_on) * my_sim.switch_th))
results.write("\ndelta_T_max [K] = " + str(my_sim.d_temp_max))
results.write("\nQ_sink [W/m2] = " + str(my_sim.q_heat))
results.write("\nq_source [W/m2] = " + str(my_sim.q_cool))
results.write("\nCOP [/] = " + str(cop))

exec_time = time.time() - start_time
results.write('\nExecution time: %.2f seconds' % exec_time)

results.close()
results_temps.close()

with open(my_sim.path + 'result.txt', 'a') as r_file:
    r_file.write('simulation\tswitch length [mm]\tmcm length [mm]\thex length [mm]\t' +
                 'frequency [Hz]\tQ_sink [W/m2]\tq_source [W/m2]\tQ_sink-q_source [W/m2]\tTds [W/m2]' +
                 '\tCOP [1]\tTsource_aver [K] \tTsink_aver [K]\tdT_max [K]\tfluctuation_c [K]\tfluctuation_c [%]' +
                 '\tfluctuation_h [K]\tfluctuation_h [%]\texec_time [s]'+ '\n')

with open(my_sim.path + 'result.txt', 'a') as r_file:
    r_file.write(my_sim.result_name +
                 '.txt\t' + str(my_sim.switch_th * 1000) + '\t' + str(my_sim.mcm_th * 1000) + '\t' +
                 str(my_sim.hex_th * 1000) + '\t' + str(my_sim.freq) + '\t' +
                 str(round(my_sim.q_heat, 2)) + '\t' + str(round(my_sim.q_cool, 2)) + '\t' +
                 str(round(my_sim.q_heat - my_sim.q_cool, 2)) +
                 '\t' + str(round(my_sim.mag_work, 2)) + '\t' + str(round(cop, 2)) +
                 '\t' + str(round(my_sim.source_average, 4)) + '\t' + str(round(my_sim.sink_average, 4)) +
                 '\t' + str(round(d_temp_max, 4)) + '\t' + str(round(my_sim.fluctuation_cold, 4)) +
                 '\t' + str(round(50 * my_sim.fluctuation_cold / my_sim.source_average, 4)) +
                 '\t' + str(round(my_sim.fluctuation_hot, 4)) +
                 '\t' + str(round(50 * my_sim.fluctuation_hot / my_sim.sink_average, 4)) +
                 '\t' + str(round(exec_time, 1)) + '\n')
