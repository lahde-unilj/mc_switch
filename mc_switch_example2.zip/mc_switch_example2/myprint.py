# Functions for oputputting the data, temperatures and other results of the simulation.


def print_darray_console(arr, x):
    n = len(arr)
    arr2 = [0 for k in range(n)]
    k = 0
    while k < n:
        arr2[k] = round(arr[k], x)
        k += 1
    print(str(arr2))


def print_darray_row(arr, afile, x, time, cycle):
    n = len(arr)
    k = 0
    afile.write(str(cycle) + '\t')
    afile.write('%.4f\t' % time)
    while k < n:
        if k != n - 1:
            if x == 2:
                afile.write('%.2f\t' % arr[k])
            elif x == 4:
                afile.write('%.4f\t' % arr[k])
            else:
                afile.write('%.0f\t' % arr[k])
        if k == n - 1:
            if x == 2:
                afile.write('%.2f' % arr[k])
            elif x == 4:
                afile.write('%.4f' % arr[k])
            else:
                afile.write('%.0f' % arr[k])
        k += 1
    afile.write('\n')


def print_first_last(arr, afile):
    afile.write('%.4f' % arr[0])
    afile.write('\n')


def print_simulation(sim, afile):
    afile.write('\n\nSIMULATION\n')
    afile.write('rho_source = ' + str(sim.rho_source) + ' kg/m3, rho_switch = ' + str(sim.rho_switch) + ' kg/m3, rho_mcm = ' + str(sim.rho_mcm) +
                ' kg/m3, rho_sink = ' + str(sim.rho_sink) + ' kg/m3, cp_source = ' + str(sim.cp_source) +
                ' J/kgK, \ncp_sink = ' + str(sim.cp_sink) + ' J/kgK, cp_switch= ' + str(sim.cp_switch) + ' J/kgK, k_source = ' + str(sim.k_source) + ' W/mK, k_sink = ' + str(sim.k_sink) +
                ' W/mK, \nk_on = ' + str(sim.k_on) + ' W/mK, k_off = ' + str(sim.k_off) +
                ' W/mK, k_mcm = ' +str(sim.k_mcm) + 'W/mK, \nq_left = ' + str(sim.q_left) + ' W/m2, h_right = ' + str(sim.h_right) + ' W/m2K,' +
                '\nlow_field = ' + str(sim.low_field) + ' T, high_field = ' + str(sim.high_field) +
                ' T, \ngenerated_heat_on = ' + str(sim.generated_heat_on) + ' W/m3, generated_heat_off = ' + str(sim.generated_heat_off) +
                ' W/m3, switch_work = ' + str(sim.switch_work) +
                ' W/m2,\nresistance_12 = ' + str(sim.resist_12) + ' mK/W, resistance_23 = ' + str(sim.resist_23) +
                ' mK/W, resistance_34 = ' + str(sim.resist_34) + ' mK/W, resistance_45 = ' + str(sim.resist_45) +
                ' mK/W\nq_input_left = ' + str(sim.q_left) + ' W/m2, right_temp = ' + str(sim.right_temp) +
                ' K\nt_mag = ' + str(sim.t_mag) + ' s, freq = ' + str(sim.freq) + ' Hz, time_step = ' + str(sim.time_step) +
                '\nhex_dx = ' + str(sim.hex_dx*1000) + ' mm, switch_dx = ' + str(sim.switch_dx*1000) + ' mm, mcm_dx = ' + str(sim.mcm_dx*1000) + ' mm,' +
                '\nn = ' + str(sim.n) + ',\nhex_th = ' + str(sim.hex_th * 1000) + ' mm, ' +
                'switch_th = ' + str(sim.switch_th*1000) + ' mm, mcm_th = ' + str(sim.mcm_th*1000) + ' mm,' +
                '\ntolerance = ' + str(sim.tolerance) +
                '\nend_tolerance = ' + str(sim.end_tolerance) + ' N = ' + str(sim.N))
    afile.write('\n')
