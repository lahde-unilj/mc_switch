# This is the tridiagonal matrix algorithm, which takes the sistem of equations
# (including current temperatures of nodes) and returns list of temperatures in the next time step.
# a = underdiagonal matrix coefficients, b = diagonal matrix coefficients, c = upperdiagonal matrix coefficients, z = right hand side


def thomas(a, b, c, z):
    m = len(b)
    U = [0 for k in range(0, m)]
    L = [0 for k in range(1, m)]
    U[0] = b[0]

    for k in range(0, m - 1):
        L[k] = a[k] / U[k]
        U[k + 1] = b[k + 1] - L[k] * c[k]

    y = [el for el in z]
    for k in range(1, m):
        y[k] = z[k] - L[k - 1] * y[k - 1]

    x = [el for el in y]
    x[m - 1] = x[m - 1] / U[m - 1]
    for k in range(m - 2, -1, -1):
        x[k] = (y[k] - c[k] * x[k + 1]) / U[k]
    return x
