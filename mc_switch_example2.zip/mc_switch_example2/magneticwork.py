import numpy as np


# This function calculates the magnetic work of the caloric material in quasi-steady state, cooling and heating power
# and fluctuation magnitude in the heat source/sink. It serves for checking the validity of the simulation results.
# The calculated values are output at the end of simulation in the result.txt file.
def mag_work(sim):
    wh, wl = 0, 0
    m = len(sim.tds_high)
    n = len(sim.tds_high[0])
    sim.mag_work = 0
    sim.q_cool = 0
    sim.q_heat = 0
    sim.d_temp_max = 0
    sim.temp_source = 0
    sim.temp_sink = 0
    sim.q_mcm = 0

    for i in range(0, n):
        for j in range(1, m):
            temp1 = sim.tds_high[j - 1][i]
            temp2 = sim.tds_high[j][i]
            s1 = np.interp(temp1, sim.temperatures_st, sim.high_field_entropies)
            s2 = np.interp(temp2, sim.temperatures_st, sim.high_field_entropies)

            wh += ((temp1 + temp2) / 2.0) * (s1 - s2) * sim.mcm_dx * sim.rho_mcm / (2.0 * sim.t_transfer)

    sim.mag_work += wh

    for i in range(0, n):
        for j in range(1, m):
            temp1 = sim.tds_low[j - 1][i]
            temp2 = sim.tds_low[j][i]
            s1 = np.interp(temp1, sim.temperatures_st, sim.low_field_entropies)
            s2 = np.interp(temp2, sim.temperatures_st, sim.low_field_entropies)

            wl += ((temp1 + temp2) / 2.0) * (s2 - s1) * sim.mcm_dx * sim.rho_mcm / (2.0 * sim.t_transfer)

    sim.mag_work -= wl

    for i in range(0, 2*m):
        sim.q_cool = sim.q_left
        sim.q_heat += (sim.sink_temps[i] - sim.right_temp)*sim.h_right/(2.0*m)
        sim.d_temp_max += (sim.sink_temps[i] - sim.source_temps[i])/(2.0*m)

    for i in range(m, 2*m):
        sim.source_average += sim.source_temps[i]/m
        sim.sink_average += sim.sink_temps[i]/m

    sim.fluctuation_cold = (sim.source_temps[2*m-1]-sim.source_temps[m-1])
    sim.fluctuation_hot = (sim.sink_temps[2*m-1]-sim.sink_temps[m-1])
    sim.temp_source = sim.source_temps[2*m-1]
    sim.temp_sink = sim.sink_temps[2*m-1]
